<footer>
      
            <div class="bg-dark">
              <div class="row py-4 d-flex align-item-center">
                <div class="col-md-6 text-right">
                  <a href="#"> <i class="fab fa-facebook-f text-white mr-4"></i></a> 
                  <a href="#"> <i class="fab fa-twitter text-white mr-4"></i></a> 
                  <a href="#"> <i class="fab fa-google-plus-g text-white mr-4"></i></a> 
                  <a href="#"> <i class="fab fa-linkedin-in text-white mr-4"></i></a> 
                  <a href="#"> <i class="fab fa-instagram text-white mr-4"></i></a> 
                </div>
                <p>
                  Copyright tuju.id 2020
                </p>
          </div>
        </div>
      
  </footer><?php /**PATH D:\laragon\www\store-apps\resources\views/includes/footer.blade.php ENDPATH**/ ?>