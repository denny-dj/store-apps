

<?php $__env->startSection('title'); ?>
    Store Home Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Content -->
    <div class="page-content page-home">
    
      <section class="store-carousel">
          <div class="">
            <div class="row">
              <div class="col-lg-12" data-aos="zoom-in">
                <div
                  id="storeCarousel"
                  class="carousel slide"
                  data-ride="carousel"
                >
                  <ol class="carousel-indicators">
                    <li
                      data-target="#storeCarousel"
                      data-slide-to="0"
                      class="active"
                    ></li>
                    <li data-target="#storeCarousel" data-slide-to="1"></li>
                    <li data-target="#storeCarousel" data-slide-to="2"></li>
                  </ol>
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                      <img
                        src="images/banner.jpg"
                        class="d-block w-100"
                        alt="Carousel Image"
                      />
                    </div>
                    <div class="carousel-item">
                      <img
                        src="images/banner.jpg"
                        class="d-block w-100"
                        alt="Carousel Image"
                      />
                    </div>
                    <div class="carousel-item">
                      <img
                        src="images/banner.jpg"
                        class="d-block w-100"
                        alt="Carousel Image"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        
        <section class="store-card-section mt-3" data-aos="fade-up" id="card">
            <div class="container">
              <div class="row">
                <div class="col text-center section-card-header">
                  <h2>Our Popular Service</h2>
                </div>
              </div>
            </div>
        </section>

        <section class="store-card-content mt-2" id="card-content">
          <div class="container">
          <div class="section-card-content row justify-content-center">
            <?php $incrumentCard = 0 ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
              <div class="card-content text-center d-flex flex-column" data-aos="fade-up" data-aos-delay="<?php echo e($incrumentCard+= 100); ?>"
              style=
                  "min-height: 380px;
                  background-color: #000;
                  color: #fff;
                  padding: 30px;
                  background-size: cover;
                  border-radius: 8px;
                  margin-bottom: 20px;
                  background-image: url('images/card-1.jpg');">
                <div class="subtitle">Make Your Site</div>
                <div class="title"><h2>WordPress</h2></div>
                <div class="card-button mt-auto">
                  <a href="#" class="btn btn-success px-4">
                    View Details
                  </a>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 col-lg-3">
              <div class="card-content text-center d-flex flex-column" data-aos="fade-up" data-aos-delay="<?php echo e($incrumentCard+= 100); ?>"
              style=
                  "min-height: 380px;
                  background-color: #000;
                  color: #fff;
                  padding: 30px;
                  background-size: cover;
                  border-radius: 8px;
                  margin-bottom: 20px;
                  background-image: url('images/card-1.jpg');">
                <div class="subtitle">Make Your Site</div>
                <div class="title"><h2>WordPress</h2></div>
                <div class="card-button mt-auto">
                  <a href="#" class="btn btn-success px-4">
                    View Details
                  </a>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 col-lg-3">
              <div class="card-content text-center d-flex flex-column" data-aos="fade-up" data-aos-delay="<?php echo e($incrumentCard+= 100); ?>"
              style=
                  "min-height: 380px;
                  background-color: #000;
                  color: #fff;
                  padding: 30px;
                  background-size: cover;
                  border-radius: 8px;
                  margin-bottom: 20px;
                  background-image: url('images/card-1.jpg');">
                <div class="subtitle">Make Your Site</div>
                <div class="title"><h2>WordPress</h2></div>
                <div class="card-button mt-auto">
                  <a href="#" class="btn btn-success px-4">
                    View Details
                  </a>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 col-lg-3">
              <div class="card-content text-center d-flex flex-column" data-aos="fade-up" data-aos-delay="<?php echo e($incrumentCard+= 100); ?>"
              style=
                  "min-height: 380px;
                  background-color: #000;
                  color: #fff;
                  padding: 30px;
                  background-size: cover;
                  border-radius: 8px;
                  margin-bottom: 20px;
                  background-image: url('images/card-1.jpg');">
                <div class="subtitle">Make Your Site</div>
                <div class="title"><h2>WordPress</h2></div>
                <div class="card-button mt-auto">
                  <a href="#" class="btn btn-success px-4">
                    View Details
                  </a>
                </div>
              </div>
            </div>
            
          </div>
          </div>
        </section>
        
        
        <section class="store-trend-categories mt-2 ">
          <div class="container">
            <div class="row">
              <div class="col-12" data-aos="fade-up">
                <h5>Trend Categories</h5>
              </div>
            </div>
            <div class="row">
              <?php $incrumentCategory = 0 ?>
              <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div
                  class="col-6 col-md-3 col-lg-2"
                  data-aos="fade-up"
                  data-aos-delay="<?php echo e($incrumentCategory+= 100); ?>">
                  <a class="component-categories d-block" href="<?php echo e(route('categories-detail', $category->slug)); ?>">
                    <div class="categories-image">
                      <img
                        src="<?php echo e(Storage::url($category->photo)); ?>"
                        alt="Gadgets Categories"
                        class="w-100"/>
                    </div>
                    <p class="categories-text">
                      <?php echo e($category->name); ?>

                    </p>
                  </a>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div  class="col-12 text-center py-5"
                    data-aos="fade-up"
                    data-aos-delay="100">
                  No Categories Found
              </div>
              <?php endif; ?>

              </div>
            </div>
          </div>
        </section>

        <section class="store-new-products mb-4">
          <div class="container">
            <div class="row">
              <div class="col-12" data-aos="fade-up">
                <h5>New Products</h5>
              </div>
            </div>
            <div class="row">
              <?php $incrumentProduct = 0 ?>
              <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div
                class="col-6 col-md-4 col-lg-3"
                data-aos="fade-up"
                data-aos-delay="<?php echo e($incrumentProduct+=100); ?>">
                <a class="component-products d-block" href="<?php echo e(route('detail', $product->slug)); ?>">
                  <div class="products-thumbnail">
                    <div
                      class="products-image"
                      style="
                        <?php if($product->galleries->count()): ?>
                          background-image: url('<?php echo e(Storage::url($product->galleries->first()->photos)); ?>')
                        <?php else: ?>
                          background-color: #eee
                        <?php endif; ?>
                      "></div>
                  </div>
                  <div class="products-text">
                    <?php echo e($product->name); ?>

                  </div>
                  <div class="products-price">
                    Rp <?php echo e(number_format($product->price)); ?>

                  </div>
                </a>
              </div>     
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div  class="col-12 text-center py-5 "
              data-aos="fade-up"
              data-aos-delay="100">
                No Categories Found
              </div>
                  
              <?php endif; ?>
  
            </div>  
          </div>
        </section>
      </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\store-apps\resources\views/pages/home.blade.php ENDPATH**/ ?>