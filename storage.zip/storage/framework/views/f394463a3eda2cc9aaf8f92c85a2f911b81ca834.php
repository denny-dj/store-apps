

<?php $__env->startSection('title'); ?>
    Dashboard Transaction Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="section-content section-dashboard-home" data-aos="fade-up">
  <div class="container-fluid">
    <div class="dashboard-heading">
      <h2 class="dashboard-title"><?php echo e($transaction->code); ?></h2>
      <p class="dashboard-subtitle">
        Transaction Details
      </p>
    </div>
    <div class="dashboard-content" id="transactionDetails">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-12 col-md-4">
                  <img
                    src="<?php echo e(Storage::url($transaction->product->galleries->first()->photos ?? '')); ?>"
                    alt=""
                    class="w-100 mb-3"/>
                </div>
                <div class="col-12 col-md-8">
                  <div class="row">
                    <div class="col-12 col-md-6">
                      <div class="product-title">Customer Name</div>
                      <div class="product-subtitle"><?php echo e($transaction->transaction->user->name); ?></div>
                    </div>
                    <div class="col-12 col-md-6">
                      <div class="product-title">Product Name</div>
                      <div class="product-subtitle">
                        <?php echo e($transaction->product->name); ?>

                      </div>
                    </div>
                    <div class="col-12 col-md-6">
                      <div class="product-title">
                        Date of Transaction
                      </div>
                      <div class="product-subtitle">
                        <?php echo e($transaction->created_at); ?>

                      </div>
                    </div>
                    <div class="col-12 col-md-6">
                      <div class="product-title">Payment Status</div>
                      <div class="product-subtitle text-danger">
                        <?php echo e($transaction->transaction->transaction_status); ?>

                      </div>
                    </div>
                    <div class="col-12 col-md-6">
                      <div class="product-title">Total Amount</div>
                      <div class="product-subtitle">Rp. <?php echo e(number_format($transaction->transaction->total_price)); ?></div>
                    </div>
                    <div class="col-12 col-md-6">
                      <div class="product-title">Mobile</div>
                      <div class="product-subtitle">
                        <?php echo e($transaction->transaction->user->phone_number); ?>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <form action="<?php echo e(route('dashboard-transaction-update', $transaction->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-script'); ?>
    
<script src="/vendor/vue/vue.js"></script>
<script>
  var transactionDetails = new Vue({
    el: "#transactionDetails",
    data: {
      status: "<?php echo e($transaction->shipping_status); ?>",
      resi: "<?php echo e($transaction->resi); ?>",
    },
  });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\store-apps\resources\views/pages/dashboard-transactions-details.blade.php ENDPATH**/ ?>